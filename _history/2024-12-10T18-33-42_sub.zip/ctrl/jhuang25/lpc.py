## https://course.ece.cmu.edu/~ece792/handouts/RS_Chap_LPC.pdf
## https://www.ee.columbia.edu/~dpwe/papers/SnelM93-fmnt.pdf
## https://ccrma.stanford.edu/~hskim08/lpc/
## https://www.mathworks.com/help/signal/ug/formant-estimation-with-lpc-coefficients.html

## lpc requires matrix stuff, which seems too hard to implement on fpga